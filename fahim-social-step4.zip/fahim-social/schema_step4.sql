-- FAHIM SOCIAL: ধাপ ৪ আপডেট (schema.sql-এর পরে চালান)
-- ১) ব্লক করা ইউজারের প্রোফাইল ব্লককারী দেখতে পারবে (আনব্লকের জন্য); যে ব্লক করেছে তার প্রোফাইল ব্লকড ইউজার দেখবে না
create or replace function public.blocked_by(a uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from blocks where blocker_id = a and blocked_id = auth.uid()) $$;
drop policy if exists "profiles read" on profiles;
create policy "profiles read" on profiles for select using (id = auth.uid() or is_admin() or not blocked_by(id));

-- ২) বন্ধুতালিকা সবাই দেখতে পারবে (শুধু accepted)
create policy "friends accepted visible" on friendships for select using (status = 'accepted');

-- ৩) প্রাইভেট প্রোফাইলের পাবলিক পোস্ট শুধু বন্ধুরা দেখবে
create or replace function public.can_see_post(p posts) returns boolean
language sql stable security definer set search_path = public as $$
  select not p.is_removed and not is_blocked(auth.uid(), p.author_id) and (
    p.author_id = auth.uid()
    or (p.group_id is not null and (is_group_member(p.group_id)
        or exists (select 1 from groups g where g.id = p.group_id and not g.is_private)))
    or (p.group_id is null and (
        (p.visibility = 'public' and (are_friends(auth.uid(), p.author_id)
           or not coalesce((select is_private from profiles where id = p.author_id), false)))
        or (p.visibility = 'friends' and are_friends(auth.uid(), p.author_id)))))
$$;

-- ৪) মেসেঞ্জার ফাংশন
create or replace function public.get_or_create_dm(other uuid) returns uuid
language plpgsql security definer set search_path = public as $$
declare cid uuid; me uuid := auth.uid();
begin
  if me is null or other = me or is_blocked(me, other) then raise exception 'not allowed'; end if;
  select c.id into cid from conversations c where not c.is_group
    and exists (select 1 from conversation_members where conversation_id = c.id and user_id = me)
    and exists (select 1 from conversation_members where conversation_id = c.id and user_id = other) limit 1;
  if cid is null then
    insert into conversations (is_group, created_by) values (false, me) returning id into cid;
    insert into conversation_members (conversation_id, user_id) values (cid, me), (cid, other);
  end if;
  return cid;
end $$;

create or replace function public.create_group_chat(gname text, members uuid[]) returns uuid
language plpgsql security definer set search_path = public as $$
declare cid uuid; me uuid := auth.uid();
begin
  if me is null or coalesce(trim(gname), '') = '' then raise exception 'invalid'; end if;
  insert into conversations (is_group, name, created_by) values (true, trim(gname), me) returning id into cid;
  insert into conversation_members (conversation_id, user_id) values (cid, me);
  insert into conversation_members (conversation_id, user_id)
    select distinct m from unnest(members) m where m <> me and are_friends(me, m) and not is_blocked(me, m);
  return cid;
end $$;

create or replace function public.unread_counts() returns table (conversation_id uuid, n bigint)
language sql stable security definer set search_path = public as $$
  select m.conversation_id, count(*) from messages m
  join conversation_members cm on cm.conversation_id = m.conversation_id and cm.user_id = auth.uid()
  where m.sender_id <> auth.uid() and m.deleted_at is null and m.created_at > cm.last_read_at
  group by m.conversation_id $$;

-- অন্যের মেসেজ শুধু delivered_at বদলাতে পারবে; কনটেন্ট/ডিলিট শুধু প্রেরক
create or replace function public.guard_message_update() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is distinct from old.sender_id then
    new.content := old.content; new.media_url := old.media_url; new.media_type := old.media_type;
    new.deleted_at := old.deleted_at; new.sender_id := old.sender_id; new.conversation_id := old.conversation_id;
  end if;
  return new;
end $$;
drop trigger if exists messages_guard on public.messages;
create trigger messages_guard before update on public.messages for each row execute function public.guard_message_update();

-- চ্যাট ফাইল: পাথ <uid>/<conversation_id>/<file>; শুধু ওই কনভারসেশনের সদস্যরা দেখবে
drop policy if exists "chat files read" on storage.objects;
create policy "chat files read" on storage.objects for select to authenticated using (
  bucket_id = 'chat-files' and (storage.foldername(name))[2] ~ '^[0-9a-f-]{36}$'
  and is_conv_member(((storage.foldername(name))[2])::uuid));

-- ৫) বন্ধুর পরামর্শ
create or replace function public.friend_suggestions() returns setof public.profiles
language sql stable security definer set search_path = public as $$
  select p.* from profiles p
  where p.id <> auth.uid() and not p.is_suspended and not is_blocked(auth.uid(), p.id)
    and not exists (select 1 from friendships f where
      (f.requester_id = auth.uid() and f.addressee_id = p.id) or (f.addressee_id = auth.uid() and f.requester_id = p.id))
  order by (select count(*) from friendships a join friendships b
      on ((a.requester_id = p.id and a.addressee_id = b.requester_id) or (a.addressee_id = p.id and a.requester_id = b.requester_id)
       or (a.requester_id = p.id and a.addressee_id = b.addressee_id) or (a.addressee_id = p.id and a.requester_id = b.addressee_id))
      where a.status = 'accepted' and b.status = 'accepted' and (b.requester_id = auth.uid() or b.addressee_id = auth.uid())) desc,
    p.created_at desc
  limit 20 $$;
