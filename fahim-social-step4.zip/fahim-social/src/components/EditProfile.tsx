'use client';
import { useState } from 'react';
import { createClient } from '@/lib/supabase/client';
import { useApp } from './Providers';
const OK = ['image/jpeg', 'image/png', 'image/webp'];
export default function EditProfile({ p, onClose, onSaved }: { p: any; onClose: () => void; onSaved: (username: string) => void }) {
  const { t } = useApp(); const sb = createClient();
  const [f, setF] = useState({ full_name: p.full_name, username: p.username, bio: p.bio ?? '', location: p.location ?? '', website: p.website ?? '', is_private: !!p.is_private });
  const [av, setAv] = useState<File | null>(null); const [cv, setCv] = useState<File | null>(null);
  const [busy, setBusy] = useState(false); const [error, setError] = useState('');
  const check = (file: File | null, max: number) => !file || (OK.includes(file.type) && file.size <= max * 1048576);
  async function up(bucket: string, file: File) {
    const path = `${p.id}/${Date.now()}.${(file.name.split('.').pop() || 'jpg').toLowerCase()}`;
    const { error } = await sb.storage.from(bucket).upload(path, file, { contentType: file.type }); if (error) throw error;
    return sb.storage.from(bucket).getPublicUrl(path).data.publicUrl;
  }
  async function save() {
    setError(''); const username = f.username.trim().toLowerCase();
    if (!f.full_name.trim()) return setError(t('errName'));
    if (!/^[a-z0-9_]{3,30}$/.test(username)) return setError(t('errUsername'));
    let site = f.website.trim(); if (site && !/^https?:\/\//i.test(site)) site = 'https://' + site;
    if (site) { try { new URL(site); } catch { return setError(t('errWebsite')); } }
    if (!check(av, 5) || !check(cv, 8)) return setError(`${t('fileType')} ${t('fileSize')}`);
    setBusy(true);
    try {
      if (username !== p.username) {
        const { data } = await sb.from('profiles').select('id').eq('username', username).neq('id', p.id).maybeSingle();
        if (data) throw new Error(t('usernameTaken'));
      }
      const patch: any = { full_name: f.full_name.trim(), username, bio: f.bio.trim() || null, location: f.location.trim() || null, website: site || null, is_private: f.is_private };
      if (av) patch.avatar_url = await up('avatars', av);
      if (cv) patch.cover_url = await up('covers', cv);
      const { error } = await sb.from('profiles').update(patch).eq('id', p.id); if (error) throw error;
      onSaved(username);
    } catch (e: any) { setError(e.message || t('loadError')); } finally { setBusy(false); }
  }
  const set = (k: string) => (e: any) => setF({ ...f, [k]: e.target.value });
  return (
    <div className="fixed inset-0 z-40 grid place-items-center bg-black/50 p-4" onClick={onClose}>
      <div className="card max-h-[90vh] w-full max-w-md space-y-3 overflow-y-auto p-5" onClick={(e) => e.stopPropagation()}>
        <h2 className="text-lg font-bold">{t('editProfile')}</h2>
        <input className="input" placeholder={t('fullName')} value={f.full_name} onChange={set('full_name')} />
        <input className="input" placeholder={t('username')} value={f.username} onChange={set('username')} autoCapitalize="none" />
        <textarea className="input" maxLength={300} placeholder={t('bio')} value={f.bio} onChange={set('bio')} />
        <input className="input" placeholder={t('location')} value={f.location} onChange={set('location')} />
        <input className="input" placeholder={t('website')} value={f.website} onChange={set('website')} />
        <label className="block text-sm">{t('changeAvatar')}<input type="file" accept={OK.join(',')} className="mt-1 block w-full text-sm" onChange={(e) => setAv(e.target.files?.[0] ?? null)} /></label>
        <label className="block text-sm">{t('changeCover')}<input type="file" accept={OK.join(',')} className="mt-1 block w-full text-sm" onChange={(e) => setCv(e.target.files?.[0] ?? null)} /></label>
        <label className="flex items-center gap-2"><input type="checkbox" checked={f.is_private} onChange={(e) => setF({ ...f, is_private: e.target.checked })} />{t('privateProfile')}</label>
        {error && <p role="alert" className="text-sm text-red-600">{error}</p>}
        <div className="flex gap-2"><button className="btn-primary flex-1" onClick={save} disabled={busy}>{busy ? t('loading') : t('save')}</button><button className="btn-ghost" onClick={onClose}>{t('cancel')}</button></div>
      </div>
    </div>);
}
