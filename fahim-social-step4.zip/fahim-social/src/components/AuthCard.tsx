'use client';
import { ReactNode } from 'react';
import { useApp } from './Providers';
export default function AuthCard({ title, children }: { title: string; children: ReactNode }) {
  const { t, lang, setLang } = useApp();
  return (
    <main className="min-h-screen grid place-items-center p-4 bg-gradient-to-br from-brand-50 to-white dark:from-slate-950 dark:to-slate-900">
      <div className="w-full max-w-md animate-fadeUp">
        <div className="text-center mb-6">
          <div className="mx-auto mb-3 grid h-14 w-14 place-items-center rounded-2xl bg-brand-500 text-2xl font-bold text-white shadow-lg">F</div>
          <h1 className="text-2xl font-bold">{t('appName')}</h1>
          <p className="text-slate-500 dark:text-slate-400">{t('tagline')}</p>
        </div>
        <div className="card p-6">
          <h2 className="mb-4 text-xl font-semibold">{title}</h2>
          {children}
        </div>
        <button className="mx-auto mt-4 block text-sm text-slate-500 hover:underline" onClick={() => setLang(lang === 'bn' ? 'en' : 'bn')}>
          {lang === 'bn' ? 'English' : 'বাংলা'}
        </button>
      </div>
    </main>
  );
}
export const Msg = ({ error, ok }: { error?: string; ok?: string }) =>
  error ? <p role="alert" className="rounded-lg bg-red-50 dark:bg-red-950 px-3 py-2 text-sm text-red-600 dark:text-red-300">{error}</p>
  : ok ? <p className="rounded-lg bg-green-50 dark:bg-green-950 px-3 py-2 text-sm text-green-700 dark:text-green-300">{ok}</p> : null;
