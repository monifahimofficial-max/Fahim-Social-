'use client';
import { ReactNode, useCallback, useEffect, useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { createClient } from '@/lib/supabase/client';
import { useApp } from './Providers';
import Avatar from './Avatar';
import { notify, refreshCounts } from '@/lib/notify';
import { Author, Me } from '@/lib/types';
type Row = { fid?: string; u: Author };
function Person({ u, children }: { u: Author; children: ReactNode }) {
  return (<div className="card flex items-center gap-3 p-3">
    <Link href={`/u/${u.username}`} className="flex min-w-0 flex-1 items-center gap-3"><Avatar name={u.full_name} url={u.avatar_url} /><div className="min-w-0"><p className="truncate font-semibold">{u.full_name}</p><p className="truncate text-sm text-slate-500">@{u.username}</p></div></Link>
    <div className="flex gap-2">{children}</div></div>);
}
export default function FriendsView({ me }: { me: Me }) {
  const { t } = useApp(); const sb = createClient(); const router = useRouter();
  const [d, setD] = useState<{ rec: Row[]; sent: Row[]; fr: Row[]; blk: Row[]; sug: Row[] } | null>(null); const [error, setError] = useState('');
  const load = useCallback(async () => {
    const P = 'id,full_name,username,avatar_url';
    const [a, b, c, e, s] = await Promise.all([
      sb.from('friendships').select(`id, u:profiles!requester_id(${P})`).eq('addressee_id', me.id).eq('status', 'pending'),
      sb.from('friendships').select(`id, u:profiles!addressee_id(${P})`).eq('requester_id', me.id).eq('status', 'pending'),
      sb.from('friendships').select(`id, requester:profiles!requester_id(${P}), addressee:profiles!addressee_id(${P})`).eq('status', 'accepted').or(`requester_id.eq.${me.id},addressee_id.eq.${me.id}`),
      sb.from('blocks').select(`u:profiles!blocked_id(${P})`).eq('blocker_id', me.id), sb.rpc('friend_suggestions')]);
    if (a.error || b.error || c.error) setError(t('loadError'));
    setD({ rec: (a.data ?? []).map((x: any) => ({ fid: x.id, u: x.u })), sent: (b.data ?? []).map((x: any) => ({ fid: x.id, u: x.u })),
      fr: (c.data ?? []).map((x: any) => ({ fid: x.id, u: x.requester.id === me.id ? x.addressee : x.requester })),
      blk: (e.data ?? []).map((x: any) => ({ u: x.u })), sug: ((s.data as any[]) ?? []).map((u) => ({ u })) });
  }, [me.id]); // eslint-disable-line
  useEffect(() => { load(); }, [load]);
  const act = async (fn: () => PromiseLike<any>) => { setError(''); const r = await fn(); if (r?.error) setError(t('loadError')); await load(); refreshCounts(); };
  async function msg(id: string) { const { data, error } = await sb.rpc('get_or_create_dm', { other: id }); if (error) return setError(t('loadError')); router.push(`/messenger?c=${data}`); }
  if (!d) return <div className="space-y-3"><div className="card h-16 animate-pulse" /><div className="card h-16 animate-pulse" /></div>;
  const Sec = ({ title, rows, children }: { title: string; rows: Row[]; children: (r: Row) => ReactNode }) => rows.length ? (
    <section className="mb-6"><h2 className="mb-2 font-bold">{title} <span className="text-slate-500">({rows.length})</span></h2><div className="space-y-2">{rows.map((r) => <Person key={r.u.id} u={r.u}>{children(r)}</Person>)}</div></section>) : null;
  const empty = !d.rec.length && !d.sent.length && !d.fr.length && !d.blk.length && !d.sug.length;
  return (<div>
    {error && <p role="alert" className="mb-3 text-sm text-red-600">{error}</p>}
    <Sec title={t('requests')} rows={d.rec}>{(r) => (<>
      <button className="btn-primary !py-1.5" onClick={() => act(async () => { const x = await sb.from('friendships').update({ status: 'accepted' }).eq('id', r.fid!); if (!x.error) await notify(sb, r.u.id, me.id, 'friend_accept'); return x; })}>{t('acceptReq')}</button>
      <button className="btn-ghost !py-1.5" onClick={() => act(() => sb.from('friendships').delete().eq('id', r.fid!))}>{t('rejectReq')}</button></>)}</Sec>
    <Sec title={t('sentRequests')} rows={d.sent}>{(r) => <button className="btn-ghost !py-1.5" onClick={() => act(() => sb.from('friendships').delete().eq('id', r.fid!))}>{t('cancelRequest')}</button>}</Sec>
    <Sec title={t('myFriends')} rows={d.fr}>{(r) => (<>
      <button className="btn-primary !py-1.5" onClick={() => msg(r.u.id)}>{t('message')}</button>
      <button className="btn-ghost !py-1.5" onClick={() => confirm(t('unfriend') + '?') && act(() => sb.from('friendships').delete().eq('id', r.fid!))}>{t('unfriend')}</button></>)}</Sec>
    <Sec title={t('suggestions')} rows={d.sug}>{(r) => (<>
      <button className="btn-primary !py-1.5" onClick={() => act(async () => { const x = await sb.from('friendships').insert({ requester_id: me.id, addressee_id: r.u.id }); if (!x.error) await notify(sb, r.u.id, me.id, 'friend_request'); return x; })}>{t('addFriend')}</button>
      <button className="btn-ghost !py-1.5" onClick={() => act(async () => { const x = await sb.from('follows').insert({ follower_id: me.id, following_id: r.u.id }); if (!x.error) await notify(sb, r.u.id, me.id, 'follow'); return x; })}>{t('follow')}</button></>)}</Sec>
    <Sec title={t('blockedUsers')} rows={d.blk}>{(r) => <button className="btn-ghost !py-1.5" onClick={() => act(() => sb.from('blocks').delete().eq('blocker_id', me.id).eq('blocked_id', r.u.id))}>{t('unblock')}</button>}</Sec>
    {empty && <div className="card p-8 text-center text-slate-500">{t('noneYet')}</div>}
  </div>);
}
