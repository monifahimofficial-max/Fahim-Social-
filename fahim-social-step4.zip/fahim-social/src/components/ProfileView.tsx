'use client';
import { useCallback, useEffect, useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { createClient } from '@/lib/supabase/client';
import { useApp } from './Providers';
import Avatar from './Avatar';
import PostList from './PostList';
import EditProfile from './EditProfile';
import { notify } from '@/lib/notify';
import { Me } from '@/lib/types';
type Tab = 'posts' | 'photos' | 'friends';
export default function ProfileView({ username, me }: { username: string; me: Me }) {
  const { t } = useApp(); const sb = createClient(); const router = useRouter();
  const [p, setP] = useState<any>(undefined);
  const [fr, setFr] = useState<any>(null); const [following, setFollowing] = useState(false); const [blocked, setBlocked] = useState(false);
  const [stats, setStats] = useState({ friends: 0, followers: 0, following: 0 });
  const [tab, setTab] = useState<Tab>('posts'); const [edit, setEdit] = useState(false); const [note, setNote] = useState(''); const [busy, setBusy] = useState(false);
  const load = useCallback(async () => {
    const { data } = await sb.from('profiles').select('id,username,full_name,bio,location,website,avatar_url,cover_url,is_private').eq('username', username).maybeSingle();
    setP(data ?? null); if (!data) return; const id = data.id;
    const [f, fo, bl, c1, c2, c3] = await Promise.all([
      sb.from('friendships').select('id,requester_id,addressee_id,status').or(`and(requester_id.eq.${me.id},addressee_id.eq.${id}),and(requester_id.eq.${id},addressee_id.eq.${me.id})`).maybeSingle(),
      sb.from('follows').select('follower_id').eq('follower_id', me.id).eq('following_id', id).maybeSingle(),
      sb.from('blocks').select('blocked_id').eq('blocker_id', me.id).eq('blocked_id', id).maybeSingle(),
      sb.from('friendships').select('id', { count: 'exact', head: true }).eq('status', 'accepted').or(`requester_id.eq.${id},addressee_id.eq.${id}`),
      sb.from('follows').select('follower_id', { count: 'exact', head: true }).eq('following_id', id),
      sb.from('follows').select('following_id', { count: 'exact', head: true }).eq('follower_id', id)]);
    setFr(f.data); setFollowing(!!fo.data); setBlocked(!!bl.data); setStats({ friends: c1.count ?? 0, followers: c2.count ?? 0, following: c3.count ?? 0 });
  }, [username, me.id]); // eslint-disable-line
  useEffect(() => { load(); }, [load]);
  if (p === undefined) return <div className="card h-64 animate-pulse" />;
  if (p === null) return <div className="card p-8 text-center text-slate-500">{t('notFound')}</div>;
  const own = p.id === me.id; const isFriend = fr?.status === 'accepted';
  const canView = own || isFriend || !p.is_private;
  const run = async (fn: () => PromiseLike<any>) => { setBusy(true); setNote(''); const r: any = await fn(); setBusy(false); if (r?.error) setNote(t('loadError')); await load(); };
  const addFriend = () => run(async () => { const r = await sb.from('friendships').insert({ requester_id: me.id, addressee_id: p.id }); if (!r.error) await notify(sb, p.id, me.id, 'friend_request'); return r; });
  const accept = () => run(async () => { const r = await sb.from('friendships').update({ status: 'accepted' }).eq('id', fr.id); if (!r.error) await notify(sb, p.id, me.id, 'friend_accept'); return r; });
  const removeFr = () => run(() => sb.from('friendships').delete().eq('id', fr.id));
  const toggleFollow = () => run(async () => {
    if (following) return sb.from('follows').delete().eq('follower_id', me.id).eq('following_id', p.id);
    const r = await sb.from('follows').insert({ follower_id: me.id, following_id: p.id }); if (!r.error) await notify(sb, p.id, me.id, 'follow'); return r;
  });
  const toggleBlock = () => {
    if (!blocked && !confirm(t('confirmBlock'))) return;
    run(async () => {
      if (blocked) return sb.from('blocks').delete().eq('blocker_id', me.id).eq('blocked_id', p.id);
      const r = await sb.from('blocks').insert({ blocker_id: me.id, blocked_id: p.id });
      if (!r.error) { if (fr) await sb.from('friendships').delete().eq('id', fr.id); await sb.from('follows').delete().eq('follower_id', me.id).eq('following_id', p.id); }
      return r;
    });
  };
  async function report() {
    const reason = prompt(t('reportReason'))?.trim(); if (!reason || reason.length < 3) return;
    const { error } = await sb.from('reports').insert({ reporter_id: me.id, reported_user_id: p.id, reason: reason.slice(0, 1000) });
    setNote(error ? t('loadError') : t('reported'));
  }
  async function message() {
    const { data, error } = await sb.rpc('get_or_create_dm', { other: p.id });
    if (error) return setNote(t('loadError')); router.push(`/messenger?c=${data}`);
  }
  const friendBtn = fr?.status === 'accepted' ? <button className="btn-ghost !py-2" onClick={removeFr} disabled={busy}>{t('unfriend')}</button>
    : fr?.requester_id === me.id ? <button className="btn-ghost !py-2" onClick={removeFr} disabled={busy}>{t('cancelRequest')}</button>
    : fr ? <><button className="btn-primary !py-2" onClick={accept} disabled={busy}>{t('acceptReq')}</button><button className="btn-ghost !py-2" onClick={removeFr} disabled={busy}>{t('rejectReq')}</button></>
    : <button className="btn-primary !py-2" onClick={addFriend} disabled={busy || blocked}>{t('addFriend')}</button>;
  return (
    <div>
      <div className="card overflow-hidden">
        <div className="h-40 bg-gradient-to-r from-brand-500 to-brand-700 sm:h-52">{p.cover_url && <img src={p.cover_url} alt="" className="h-full w-full object-cover" />}</div>
        <div className="p-4">
          <div className="-mt-14 flex items-end gap-3"><div className="rounded-full border-4 border-white dark:border-slate-900"><Avatar name={p.full_name} url={p.avatar_url} size={88} /></div></div>
          <h1 className="mt-2 text-xl font-bold">{p.full_name}</h1><p className="text-sm text-slate-500">@{p.username}</p>
          {p.bio && <p className="mt-2 whitespace-pre-wrap">{p.bio}</p>}
          <p className="mt-1 text-sm text-slate-500">{[p.location, p.website && p.website.replace(/^https?:\/\//, '')].filter(Boolean).join(' · ')}</p>
          {p.website && /^https?:\/\//i.test(p.website) && <a href={p.website} target="_blank" rel="noopener noreferrer nofollow" className="text-sm text-brand-600 hover:underline">{p.website}</a>}
          <p className="mt-2 text-sm"><b>{stats.friends}</b> {t('friends')} · <b>{stats.followers}</b> {t('followers')} · <b>{stats.following}</b> {t('followingLabel')}</p>
          <div className="mt-3 flex flex-wrap gap-2">
            {own ? <button className="btn-primary !py-2" onClick={() => setEdit(true)}>{t('editProfile')}</button> : <>
              {friendBtn}
              <button className="btn-ghost !py-2" onClick={toggleFollow} disabled={busy || blocked}>{following ? t('unfollow') : t('follow')}</button>
              <button className="btn-ghost !py-2" onClick={message} disabled={blocked}>{t('message')}</button>
              <button className="btn-ghost !py-2" onClick={toggleBlock} disabled={busy}>{blocked ? t('unblock') : t('block')}</button>
              <button className="btn-ghost !py-2" onClick={report}>{t('report')}</button></>}
          </div>
          {note && <p className="mt-2 text-sm text-slate-500">{note}</p>}
        </div>
      </div>
      <div className="my-4 flex gap-2">{(['posts', 'photos', 'friends'] as Tab[]).map((k) => (
        <button key={k} onClick={() => setTab(k)} className={tab === k ? 'btn-primary !py-2' : 'btn-ghost !py-2'}>{t(k === 'photos' ? 'tabPhotos' : k === 'friends' ? 'friends' : 'posts')}</button>))}</div>
      {!canView ? <div className="card p-6 text-center text-slate-500">{t('privateNote')}</div>
        : tab === 'posts' ? <PostList authorId={p.id} me={me} />
        : tab === 'photos' ? <Photos id={p.id} /> : <Friends id={p.id} />}
      {edit && <EditProfile p={p} onClose={() => setEdit(false)} onSaved={(u) => { setEdit(false); if (u !== p.username) router.replace(`/u/${u}`); else load(); router.refresh(); }} />}
    </div>);
}
function Photos({ id }: { id: string }) {
  const { t } = useApp(); const sb = createClient(); const [list, setList] = useState<any[] | null>(null);
  useEffect(() => { sb.from('post_media').select('url, posts!inner(author_id,created_at)').eq('media_type', 'image').eq('posts.author_id', id).order('created_at', { referencedTable: 'posts', ascending: false }).limit(60).then(({ data }) => setList(data ?? [])); }, [id]); // eslint-disable-line
  if (!list) return <div className="card h-28 animate-pulse" />;
  if (!list.length) return <div className="card p-6 text-center text-slate-500">{t('noneYet')}</div>;
  return <div className="grid grid-cols-3 gap-1 overflow-hidden rounded-2xl">{list.map((m) => <a key={m.url} href={m.url} target="_blank" rel="noopener noreferrer"><img src={m.url} alt="" loading="lazy" className="aspect-square w-full object-cover" /></a>)}</div>;
}
function Friends({ id }: { id: string }) {
  const { t } = useApp(); const sb = createClient(); const [list, setList] = useState<any[] | null>(null);
  useEffect(() => { (async () => {
    const { data } = await sb.from('friendships').select('requester:profiles!requester_id(id,full_name,username,avatar_url), addressee:profiles!addressee_id(id,full_name,username,avatar_url)')
      .eq('status', 'accepted').or(`requester_id.eq.${id},addressee_id.eq.${id}`).limit(100);
    setList((data ?? []).map((r: any) => (r.requester.id === id ? r.addressee : r.requester)));
  })(); }, [id]); // eslint-disable-line
  if (!list) return <div className="card h-28 animate-pulse" />;
  if (!list.length) return <div className="card p-6 text-center text-slate-500">{t('noneYet')}</div>;
  return <div className="grid gap-2 sm:grid-cols-2">{list.map((u) => (
    <Link key={u.id} href={`/u/${u.username}`} className="card flex items-center gap-3 p-3 hover:bg-slate-50 dark:hover:bg-slate-800"><Avatar name={u.full_name} url={u.avatar_url} /><div><p className="font-semibold">{u.full_name}</p><p className="text-sm text-slate-500">@{u.username}</p></div></Link>))}</div>;
}
