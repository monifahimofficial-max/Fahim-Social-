'use client';
import { useRef, useState } from 'react';
import { ImagePlus, X } from 'lucide-react';
import { createClient } from '@/lib/supabase/client';
import { useApp } from './Providers';
import Avatar from './Avatar';
import { Me, Visibility } from '@/lib/types';
const OK = ['image/jpeg', 'image/png', 'image/webp', 'video/mp4', 'video/webm'];
export default function Composer({ me, onPosted }: { me: Me; onPosted: () => void }) {
  const { t } = useApp(); const sb = createClient(); const pick = useRef<HTMLInputElement>(null);
  const [content, setContent] = useState(''); const [vis, setVis] = useState<Visibility>('public');
  const [files, setFiles] = useState<{ file: File; preview: string }[]>([]);
  const [busy, setBusy] = useState(false); const [progress, setProgress] = useState(''); const [error, setError] = useState('');
  function onPick(e: React.ChangeEvent<HTMLInputElement>) {
    setError(''); const list = Array.from(e.target.files ?? []); e.target.value = '';
    if (files.length + list.length > 4) return setError(t('maxFiles'));
    for (const f of list) {
      if (!OK.includes(f.type)) return setError(t('fileType'));
      if (f.size > (f.type.startsWith('video') ? 100 : 10) * 1048576) return setError(t('fileSize'));
    }
    setFiles([...files, ...list.map((file) => ({ file, preview: URL.createObjectURL(file) }))]);
  }
  async function submit() {
    const text = content.trim();
    if (!text && !files.length) return setError(t('emptyPost'));
    setBusy(true); setError('');
    const up: { path: string; url: string; type: 'image' | 'video' }[] = [];
    try {
      for (let i = 0; i < files.length; i++) {
        setProgress(`${t('uploading')} ${i + 1}/${files.length}`);
        const f = files[i].file; const ext = (f.name.split('.').pop() || 'bin').toLowerCase();
        const path = `${me.id}/${crypto.randomUUID()}.${ext}`;
        const { error } = await sb.storage.from('post-media').upload(path, f, { contentType: f.type });
        if (error) throw error;
        up.push({ path, url: sb.storage.from('post-media').getPublicUrl(path).data.publicUrl, type: f.type.startsWith('video') ? 'video' : 'image' });
      }
      const { data: post, error: pe } = await sb.from('posts').insert({ author_id: me.id, content: text || null, visibility: vis }).select('id').single();
      if (pe) throw pe;
      if (up.length) {
        const { error: me2 } = await sb.from('post_media').insert(up.map((u, i) => ({ post_id: post.id, url: u.url, media_type: u.type, position: i })));
        if (me2) { await sb.from('posts').delete().eq('id', post.id); throw me2; }
      }
      setContent(''); setFiles([]); onPosted();
    } catch (e: any) {
      if (up.length) await sb.storage.from('post-media').remove(up.map((u) => u.path));
      setError(String(e?.message).includes('Rate limit') ? t('tooMany') : e?.message || t('loadError'));
    } finally { setBusy(false); setProgress(''); }
  }
  return (
    <div className="card mb-4 p-4">
      <div className="flex gap-3">
        <Avatar name={me.full_name} url={me.avatar_url} />
        <textarea className="input min-h-[72px] resize-none" maxLength={5000} placeholder={t('whatsOnMind')} value={content} onChange={(e) => setContent(e.target.value)} />
      </div>
      {files.length > 0 && (
        <div className="mt-3 grid grid-cols-2 gap-2">
          {files.map((f, i) => (
            <div key={f.preview} className="relative overflow-hidden rounded-xl bg-slate-100 dark:bg-slate-800">
              {f.file.type.startsWith('video') ? <video src={f.preview} className="h-40 w-full object-cover" /> : <img src={f.preview} alt="" className="h-40 w-full object-cover" />}
              <button aria-label="remove" onClick={() => setFiles(files.filter((_, j) => j !== i))} className="absolute right-1 top-1 rounded-full bg-black/60 p-1 text-white"><X size={16} /></button>
            </div>))}
        </div>)}
      {error && <p role="alert" className="mt-2 text-sm text-red-600">{error}</p>}
      <div className="mt-3 flex flex-wrap items-center gap-2">
        <input ref={pick} type="file" hidden multiple accept={OK.join(',')} onChange={onPick} />
        <button type="button" className="btn-ghost !px-3 !py-2" onClick={() => pick.current?.click()} disabled={busy}><ImagePlus size={18} />{t('addMedia')}</button>
        <select className="input !w-auto !py-2" value={vis} onChange={(e) => setVis(e.target.value as Visibility)}>
          <option value="public">{t('public')}</option><option value="friends">{t('friendsOnly')}</option><option value="private">{t('onlyMe')}</option>
        </select>
        <button className="btn-primary ml-auto !py-2" onClick={submit} disabled={busy}>{busy ? progress || t('posting') : t('post')}</button>
      </div>
    </div>
  );
}
