'use client';
import { useState } from 'react';
import { MessageCircle, Share2, ThumbsUp, Pencil, Trash2, ChevronDown } from 'lucide-react';
import { createClient } from '@/lib/supabase/client';
import { useApp } from './Providers';
import Avatar from './Avatar';
import Comments from './Comments';
import { timeAgo } from '@/lib/time';
import { Extra, Me, Post, REACTIONS, RType } from '@/lib/types';
export default function PostCard({ post, extra, me, onDeleted, onShared }: { post: Post; extra: Extra; me: Me; onDeleted: (id: string) => void; onShared: () => void }) {
  const { t, lang } = useApp(); const sb = createClient();
  const [content, setContent] = useState(post.content); const [edited, setEdited] = useState(post.edited_at);
  const [editing, setEditing] = useState(false); const [draft, setDraft] = useState(post.content ?? '');
  const [counts, setCounts] = useState(extra.counts); const [mine, setMine] = useState<RType | null>(extra.mine);
  const [picker, setPicker] = useState(false); const [open, setOpen] = useState(false); const [nComments, setN] = useState(extra.comments);
  const [error, setError] = useState(''); const [note, setNote] = useState('');
  const isMine = post.author_id === me.id; const total = Object.values(counts).reduce((a, b) => a + (b ?? 0), 0);
  async function react(type: RType) {
    setPicker(false); setError(''); const prev = mine;
    const next: Record<string, number> = { ...counts };
    if (prev) next[prev] = Math.max(0, (next[prev] ?? 1) - 1);
    const clearing = prev === type; if (!clearing) next[type] = (next[type] ?? 0) + 1;
    setCounts(next); setMine(clearing ? null : type);
    const q = clearing ? sb.from('reactions').delete().eq('post_id', post.id).eq('user_id', me.id)
      : prev ? sb.from('reactions').update({ type }).eq('post_id', post.id).eq('user_id', me.id)
      : sb.from('reactions').insert({ post_id: post.id, user_id: me.id, type });
    const { error } = await q;
    if (error) { setCounts(counts); setMine(prev); return setError(t('loadError')); }
    if (!prev && post.author_id !== me.id) await sb.from('notifications').insert({ user_id: post.author_id, actor_id: me.id, type: 'like', post_id: post.id });
  }
  async function save() {
    const v = draft.trim(); if (!v && !post.media.length && !post.shared_post_id) return setError(t('emptyPost'));
    const now = new Date().toISOString();
    const { error } = await sb.from('posts').update({ content: v || null, edited_at: now }).eq('id', post.id);
    if (error) return setError(t('loadError'));
    setContent(v || null); setEdited(now); setEditing(false); setError('');
  }
  async function del() {
    if (!confirm(t('confirmDelete'))) return;
    const { error } = await sb.from('posts').delete().eq('id', post.id);
    if (error) return setError(t('loadError'));
    const paths = post.media.map((m) => m.url.split('/post-media/')[1]).filter(Boolean);
    if (paths.length) await sb.storage.from('post-media').remove(paths);
    onDeleted(post.id);
  }
  async function share() {
    const { error } = await sb.from('posts').insert({ author_id: me.id, shared_post_id: post.shared_post_id ?? post.id, visibility: 'public' });
    if (error) return setError(error.message.includes('Rate limit') ? t('tooMany') : t('loadError'));
    if (post.author_id !== me.id) await sb.from('notifications').insert({ user_id: post.author_id, actor_id: me.id, type: 'share', post_id: post.id });
    setNote(t('shared')); onShared();
  }
  const myEmoji = REACTIONS.find((r) => r.k === mine)?.e;
  return (
    <article className="card mb-4 p-4">
      <header className="flex items-center gap-3">
        <Avatar name={post.author.full_name} url={post.author.avatar_url} />
        <div className="min-w-0 flex-1">
          <p className="truncate font-semibold">{post.author.full_name} <span className="text-sm font-normal text-slate-500">@{post.author.username}</span></p>
          <p className="text-xs text-slate-500">{timeAgo(post.created_at, lang, t('justNow'))}{edited && ` · ${t('edited')}`} · {t(post.visibility === 'public' ? 'public' : post.visibility === 'friends' ? 'friendsOnly' : 'onlyMe')}</p>
        </div>
        {isMine && <div className="flex gap-1">
          <button aria-label={t('edit')} onClick={() => { setDraft(content ?? ''); setEditing(!editing); }} className="rounded-full p-2 hover:bg-slate-100 dark:hover:bg-slate-800"><Pencil size={16} /></button>
          <button aria-label={t('delete')} onClick={del} className="rounded-full p-2 text-red-600 hover:bg-slate-100 dark:hover:bg-slate-800"><Trash2 size={16} /></button></div>}
      </header>
      {editing ? (
        <div className="mt-3"><textarea className="input min-h-[80px]" maxLength={5000} value={draft} onChange={(e) => setDraft(e.target.value)} />
          <div className="mt-2 flex gap-2"><button className="btn-primary !py-2" onClick={save}>{t('save')}</button><button className="btn-ghost !py-2" onClick={() => setEditing(false)}>{t('cancel')}</button></div></div>
      ) : content && <p className="mt-3 whitespace-pre-wrap break-words">{content}</p>}
      {post.shared && (
        <div className="mt-3 rounded-xl border border-slate-200 p-3 dark:border-slate-700">
          <p className="text-sm font-semibold">{post.shared.author.full_name} <span className="font-normal text-slate-500">@{post.shared.author.username}</span></p>
          <p className="mt-1 whitespace-pre-wrap break-words text-sm">{post.shared.content}</p></div>)}
      {post.media.length > 0 && (
        <div className={`mt-3 grid gap-1 overflow-hidden rounded-xl ${post.media.length > 1 ? 'grid-cols-2' : ''}`}>
          {[...post.media].sort((a, b) => a.position - b.position).map((m) => m.media_type === 'video'
            ? <video key={m.url} src={m.url} controls preload="metadata" className="max-h-[420px] w-full bg-black object-contain" />
            : <img key={m.url} src={m.url} alt="" loading="lazy" className="max-h-[420px] w-full object-cover" />)}
        </div>)}
      {(total > 0 || nComments > 0) && (
        <div className="mt-3 flex justify-between text-sm text-slate-500">
          <span>{REACTIONS.filter((r) => counts[r.k]).map((r) => r.e).join('')} {total || ''}</span>
          <button onClick={() => setOpen(!open)} className="hover:underline">{nComments} {t('commentsLabel')}</button></div>)}
      <div className="mt-2 flex items-center border-y border-slate-200 py-1 dark:border-slate-800">
        <button onClick={() => react(mine ?? 'like')} className={`flex flex-1 items-center justify-center gap-1.5 rounded-lg py-2 text-sm font-medium hover:bg-slate-100 dark:hover:bg-slate-800 ${mine ? 'text-brand-600' : ''}`}>
          {myEmoji ?? <ThumbsUp size={18} />}{t('like')}</button>
        <button aria-label="reactions" onClick={() => setPicker(!picker)} className="rounded-lg p-2 hover:bg-slate-100 dark:hover:bg-slate-800"><ChevronDown size={16} /></button>
        <button onClick={() => setOpen(!open)} className="flex flex-1 items-center justify-center gap-1.5 rounded-lg py-2 text-sm font-medium hover:bg-slate-100 dark:hover:bg-slate-800"><MessageCircle size={18} />{t('comment')}</button>
        {post.visibility === 'public' && <button onClick={share} className="flex flex-1 items-center justify-center gap-1.5 rounded-lg py-2 text-sm font-medium hover:bg-slate-100 dark:hover:bg-slate-800"><Share2 size={18} />{t('share')}</button>}
      </div>
      {picker && <div className="mt-2 flex justify-center gap-2 rounded-full bg-slate-100 p-2 dark:bg-slate-800">
        {REACTIONS.map((r) => <button key={r.k} onClick={() => react(r.k)} className="text-2xl transition hover:scale-125" aria-label={r.k}>{r.e}</button>)}</div>}
      {note && <p className="mt-2 text-sm text-green-600">{note}</p>}
      {error && <p role="alert" className="mt-2 text-sm text-red-600">{error}</p>}
      {open && <Comments postId={post.id} postAuthorId={post.author_id} me={me} onCount={(d) => setN((n) => Math.max(0, n + d))} />}
    </article>);
}
