export default function Avatar({ name, url, size = 40 }: { name: string; url?: string | null; size?: number }) {
  const st = { width: size, height: size };
  return url ? <img src={url} alt="" style={st} className="shrink-0 rounded-full object-cover" />
    : <div style={st} className="grid shrink-0 place-items-center rounded-full bg-brand-500 font-semibold text-white">{name.trim().charAt(0).toUpperCase()}</div>;
}
