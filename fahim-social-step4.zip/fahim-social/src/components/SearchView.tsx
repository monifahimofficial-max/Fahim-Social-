'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import { createClient } from '@/lib/supabase/client';
import { useApp } from './Providers';
import Avatar from './Avatar';
import PostCard from './PostCard';
import { loadExtras, SELECT } from '@/lib/posts';
import { Extra, Me, Post } from '@/lib/types';
export default function SearchView({ me }: { me: Me }) {
  const { t } = useApp(); const sb = createClient();
  const [q, setQ] = useState(''); const [users, setUsers] = useState<any[]>([]); const [posts, setPosts] = useState<Post[]>([]); const [ex, setEx] = useState<Record<string, Extra>>({});
  const [tags, setTags] = useState<string[]>([]); const [trend, setTrend] = useState<any[]>([]); const [loading, setLoading] = useState(false); const [done, setDone] = useState(false); const [error, setError] = useState('');
  useEffect(() => { sb.from('trending_hashtags').select('tag,uses').then(({ data }) => setTrend(data ?? [])); }, []); // eslint-disable-line
  useEffect(() => {
    const clean = q.replace(/[%,()*\\]/g, ' ').trim();
    if (clean.replace('#', '').length < 2) { setUsers([]); setPosts([]); setTags([]); setDone(false); return; }
    const h = setTimeout(async () => {
      setLoading(true); setError('');
      try {
        const isTag = clean.startsWith('#'); const tag = clean.replace(/^#/, '').toLowerCase();
        let rows: Post[] = [];
        if (isTag) {
          const { data: h } = await sb.from('hashtags').select('post_id').eq('tag', tag).limit(50);
          const ids = (h ?? []).map((x: any) => x.post_id);
          if (ids.length) rows = ((await sb.from('posts').select(SELECT).in('id', ids).order('created_at', { ascending: false })).data as unknown as Post[]) ?? [];
          setUsers([]); setTags([]);
        } else {
          const [u, p, tg] = await Promise.all([
            sb.from('profiles').select('id,full_name,username,avatar_url').or(`username.ilike.%${clean}%,full_name.ilike.%${clean}%`).eq('is_suspended', false).limit(8),
            sb.from('posts').select(SELECT).ilike('content', `%${clean}%`).is('group_id', null).order('created_at', { ascending: false }).limit(10),
            sb.from('hashtags').select('tag').ilike('tag', `${tag}%`).limit(30)]);
          setUsers(u.data ?? []); rows = (p.data as unknown as Post[]) ?? []; setTags(Array.from(new Set((tg.data ?? []).map((x: any) => x.tag as string))).slice(0, 6));
        }
        setPosts(rows); setEx(await loadExtras(sb, rows, me.id)); setDone(true);
      } catch { setError(t('loadError')); } finally { setLoading(false); }
    }, 300);
    return () => clearTimeout(h);
  }, [q]); // eslint-disable-line
  return (<div>
    <input className="input mb-4" autoFocus type="search" placeholder={t('searchPlaceholder')} value={q} onChange={(e) => setQ(e.target.value)} />
    {error && <p role="alert" className="mb-2 text-sm text-red-600">{error}</p>}
    {!done && !loading && trend.length > 0 && (<section className="card p-4"><h2 className="mb-2 font-bold">{t('trending')}</h2><div className="flex flex-wrap gap-2">
      {trend.map((x) => <button key={x.tag} className="btn-ghost !py-1.5 text-sm" onClick={() => setQ('#' + x.tag)}>#{x.tag} <span className="text-slate-500">{x.uses}</span></button>)}</div></section>)}
    {loading && <div className="card h-20 animate-pulse" />}
    {tags.length > 0 && <div className="mb-3 flex flex-wrap gap-2">{tags.map((x) => <button key={x} className="btn-ghost !py-1.5 text-sm" onClick={() => setQ('#' + x)}>#{x}</button>)}</div>}
    {users.length > 0 && <section className="mb-4"><h2 className="mb-2 font-bold">{t('people')}</h2><div className="space-y-2">{users.map((u) => (
      <Link key={u.id} href={`/u/${u.username}`} className="card flex items-center gap-3 p-3"><Avatar name={u.full_name} url={u.avatar_url} /><div><p className="font-semibold">{u.full_name}</p><p className="text-sm text-slate-500">@{u.username}</p></div></Link>))}</div></section>}
    {posts.length > 0 && <section><h2 className="mb-2 font-bold">{t('posts')}</h2>{posts.map((p) => <PostCard key={p.id} post={p} extra={ex[p.id]} me={me} onDeleted={(id) => setPosts((x) => x.filter((y) => y.id !== id))} onShared={() => {}} />)}</section>}
    {done && !loading && !users.length && !posts.length && <div className="card p-6 text-center text-slate-500">{t('noResults')}</div>}
  </div>);
}
