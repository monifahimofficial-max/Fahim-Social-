'use client';
import { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import { dict, Key, Lang } from '@/lib/i18n';
type Theme = 'light' | 'dark';
type Ctx = { lang: Lang; setLang: (l: Lang) => void; theme: Theme; setTheme: (t: Theme) => void; t: (k: Key) => string };
const C = createContext<Ctx>(null!);
export const useApp = () => useContext(C);
export default function Providers({ children }: { children: ReactNode }) {
  const [lang, setL] = useState<Lang>('bn');
  const [theme, setT] = useState<Theme>('light');
  useEffect(() => {
    try { const l = localStorage.getItem('lang'); if (l === 'en' || l === 'bn') setL(l); } catch {}
    setT(document.documentElement.classList.contains('dark') ? 'dark' : 'light');
  }, []);
  useEffect(() => { document.documentElement.lang = lang; }, [lang]);
  const setLang = (l: Lang) => { setL(l); try { localStorage.setItem('lang', l); } catch {} };
  const setTheme = (x: Theme) => {
    setT(x); document.documentElement.classList.toggle('dark', x === 'dark');
    try { localStorage.setItem('theme', x); } catch {}
  };
  return <C.Provider value={{ lang, setLang, theme, setTheme, t: (k) => dict[lang][k] }}>{children}</C.Provider>;
}
