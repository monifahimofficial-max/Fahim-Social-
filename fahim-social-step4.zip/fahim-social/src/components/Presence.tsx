'use client';
import { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import { createClient } from '@/lib/supabase/client';
const C = createContext<Set<string>>(new Set());
export const useOnline = () => useContext(C);
export default function Presence({ userId, children }: { userId: string; children: ReactNode }) {
  const [online, setOnline] = useState<Set<string>>(new Set());
  useEffect(() => {
    const sb = createClient();
    const ch = sb.channel('online', { config: { presence: { key: userId } } });
    ch.on('presence', { event: 'sync' }, () => setOnline(new Set(Object.keys(ch.presenceState()))))
      .subscribe(async (s) => { if (s === 'SUBSCRIBED') await ch.track({ at: Date.now() }); });
    return () => { sb.removeChannel(ch); };
  }, [userId]);
  return <C.Provider value={online}>{children}</C.Provider>;
}
