'use client';
import { useEffect, useState } from 'react';
import { createClient } from '@/lib/supabase/client';
import { useApp } from './Providers';
import Avatar from './Avatar';
import { timeAgo } from '@/lib/time';
import { Author, Me } from '@/lib/types';
type C = { id: string; parent_id: string | null; content: string; created_at: string; author_id: string; author: Author };
export default function Comments({ postId, postAuthorId, me, onCount }: { postId: string; postAuthorId: string; me: Me; onCount: (d: number) => void }) {
  const { t, lang } = useApp(); const sb = createClient();
  const [list, setList] = useState<C[] | null>(null); const [text, setText] = useState(''); const [to, setTo] = useState<C | null>(null);
  const [error, setError] = useState(''); const [busy, setBusy] = useState(false);
  useEffect(() => { (async () => {
    const { data, error } = await sb.from('comments').select('id,parent_id,content,created_at,author_id,author:profiles!author_id(id,full_name,username,avatar_url)')
      .eq('post_id', postId).order('created_at');
    if (error) setError(t('loadError')); setList((data as unknown as C[]) ?? []);
  })(); }, [postId]); // eslint-disable-line
  async function send() {
    const content = text.trim(); if (!content) return; setBusy(true); setError('');
    const parent = to ? (to.parent_id ?? to.id) : null;
    const { data, error } = await sb.from('comments').insert({ post_id: postId, author_id: me.id, parent_id: parent, content })
      .select('id,parent_id,content,created_at,author_id,author:profiles!author_id(id,full_name,username,avatar_url)').single();
    setBusy(false);
    if (error) return setError(error.message.includes('Rate limit') ? t('tooMany') : t('loadError'));
    setList([...(list ?? []), data as unknown as C]); setText(''); setTo(null); onCount(1);
    const target = to ? to.author_id : postAuthorId;
    if (target !== me.id) await sb.from('notifications').insert({ user_id: target, actor_id: me.id, type: to ? 'reply' : 'comment', post_id: postId });
  }
  async function del(c: C) {
    if (!confirm(t('confirmDeleteComment'))) return;
    const { error } = await sb.from('comments').delete().eq('id', c.id);
    if (error) return setError(t('loadError'));
    const gone = (list ?? []).filter((x) => x.id === c.id || x.parent_id === c.id).length;
    setList((list ?? []).filter((x) => x.id !== c.id && x.parent_id !== c.id)); onCount(-gone);
  }
  const row = (c: C, reply = false) => (
    <div key={c.id} className={`flex gap-2 ${reply ? 'ml-10 mt-2' : 'mt-3'}`}>
      <Avatar name={c.author.full_name} url={c.author.avatar_url} size={32} />
      <div className="min-w-0">
        <div className="rounded-2xl bg-slate-100 px-3 py-2 dark:bg-slate-800">
          <p className="text-sm font-semibold">{c.author.full_name}</p><p className="whitespace-pre-wrap break-words text-sm">{c.content}</p>
        </div>
        <div className="mt-1 flex gap-3 px-2 text-xs text-slate-500">
          <span>{timeAgo(c.created_at, lang, t('justNow'))}</span>
          <button onClick={() => setTo(c)} className="font-medium hover:underline">{t('reply')}</button>
          {c.author_id === me.id && <button onClick={() => del(c)} className="font-medium text-red-600 hover:underline">{t('delete')}</button>}
        </div>
      </div>
    </div>);
  return (
    <div className="mt-2 border-t border-slate-200 pt-1 dark:border-slate-800">
      {list === null && <p className="py-3 text-sm text-slate-500">{t('loading')}</p>}
      {(list ?? []).filter((c) => !c.parent_id).map((c) => (
        <div key={c.id}>{row(c)}{(list ?? []).filter((r) => r.parent_id === c.id).map((r) => row(r, true))}</div>))}
      {to && <p className="mt-3 text-xs text-slate-500">{t('replyingTo')} {to.author.full_name} · <button className="underline" onClick={() => setTo(null)}>{t('cancel')}</button></p>}
      <div className="mt-3 flex gap-2">
        <input className="input !rounded-full !py-2" maxLength={2000} placeholder={t('writeComment')} value={text} onChange={(e) => setText(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && !busy && send()} />
        <button className="btn-primary !rounded-full !py-2" onClick={send} disabled={busy || !text.trim()}>{t('post')}</button>
      </div>
      {error && <p role="alert" className="mt-2 text-sm text-red-600">{error}</p>}
    </div>);
}
