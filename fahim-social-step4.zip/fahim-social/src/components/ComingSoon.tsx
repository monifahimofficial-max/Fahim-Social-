'use client';
import { useApp } from './Providers';
import { Key } from '@/lib/i18n';
export default function ComingSoon({ k }: { k: Key }) {
  const { t } = useApp();
  return (<div className="card p-8 text-center"><h1 className="mb-2 text-xl font-bold">{t(k)}</h1><p className="text-slate-500">{t('soon')}</p></div>);
}
