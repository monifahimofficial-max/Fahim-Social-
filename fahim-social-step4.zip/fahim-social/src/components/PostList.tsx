'use client';
import { useCallback, useEffect, useState } from 'react';
import { createClient } from '@/lib/supabase/client';
import { useApp } from './Providers';
import PostCard from './PostCard';
import { loadExtras, SELECT } from '@/lib/posts';
import { Extra, Me, Post } from '@/lib/types';
const PAGE = 10;
export default function PostList({ authorId, me }: { authorId: string; me: Me }) {
  const { t } = useApp(); const sb = createClient();
  const [posts, setPosts] = useState<Post[]>([]); const [ex, setEx] = useState<Record<string, Extra>>({});
  const [loading, setLoading] = useState(true); const [more, setMore] = useState(false); const [error, setError] = useState(false);
  const load = useCallback(async (cursor?: string) => {
    setLoading(true); setError(false);
    let q = sb.from('posts').select(SELECT).eq('author_id', authorId).is('group_id', null).order('created_at', { ascending: false }).limit(PAGE);
    if (cursor) q = q.lt('created_at', cursor);
    const { data, error } = await q;
    if (error) { setError(true); setLoading(false); return; }
    const rows = (data as unknown as Post[]) ?? []; const e = await loadExtras(sb, rows, me.id);
    setPosts((p) => (cursor ? [...p, ...rows] : rows)); setEx((x) => ({ ...x, ...e })); setMore(rows.length === PAGE); setLoading(false);
  }, [authorId, me.id]); // eslint-disable-line
  useEffect(() => { load(); }, [load]);
  return (<div>
    {posts.map((p) => <PostCard key={p.id} post={p} extra={ex[p.id]} me={me} onDeleted={(id) => setPosts((x) => x.filter((y) => y.id !== id))} onShared={() => load()} />)}
    {loading && <div className="card h-28 animate-pulse" />}
    {error && <div className="card p-4 text-center"><p className="mb-2 text-red-600">{t('loadError')}</p><button className="btn-primary" onClick={() => load(posts.at(-1)?.created_at)}>{t('retry')}</button></div>}
    {!loading && !error && !posts.length && <div className="card p-6 text-center text-slate-500">{t('noneYet')}</div>}
    {more && !loading && <div className="text-center"><button className="btn-ghost" onClick={() => load(posts.at(-1)?.created_at)}>{t('loadMore')}</button></div>}
  </div>);
}
