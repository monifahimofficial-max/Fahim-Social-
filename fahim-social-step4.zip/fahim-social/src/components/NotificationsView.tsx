'use client';
import { useCallback, useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { createClient } from '@/lib/supabase/client';
import { useApp } from './Providers';
import Avatar from './Avatar';
import { timeAgo } from '@/lib/time';
import { refreshCounts } from '@/lib/notify';
import { Key } from '@/lib/i18n';
import { Me } from '@/lib/types';
export default function NotificationsView({ me }: { me: Me }) {
  const { t, lang } = useApp(); const sb = createClient(); const router = useRouter();
  const [list, setList] = useState<any[] | null>(null); const [error, setError] = useState('');
  const load = useCallback(async () => {
    const { data, error } = await sb.from('notifications').select('id,type,is_read,created_at,actor:profiles!actor_id(id,full_name,username,avatar_url)').eq('user_id', me.id).order('created_at', { ascending: false }).limit(60);
    if (error) setError(t('loadError')); setList(data ?? []);
  }, [me.id]); // eslint-disable-line
  useEffect(() => {
    load();
    const ch = sb.channel('notif-page').on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'notifications', filter: `user_id=eq.${me.id}` }, load).subscribe();
    return () => { sb.removeChannel(ch); };
  }, [load, me.id]); // eslint-disable-line
  async function open(n: any) {
    if (!n.is_read) { await sb.from('notifications').update({ is_read: true }).eq('id', n.id); refreshCounts(); }
    router.push(n.type === 'friend_request' ? '/friends' : ['friend_accept', 'follow'].includes(n.type) && n.actor ? `/u/${n.actor.username}` : n.type === 'message' ? '/messenger' : '/');
  }
  async function readAll() { await sb.from('notifications').update({ is_read: true }).eq('user_id', me.id).eq('is_read', false); await load(); refreshCounts(); }
  async function clear() { await sb.from('notifications').delete().eq('user_id', me.id); await load(); refreshCounts(); }
  if (!list) return <div className="card h-24 animate-pulse" />;
  return (<div>
    <div className="mb-3 flex items-center justify-between"><h1 className="text-xl font-bold">{t('notifications')}</h1>
      {list.length > 0 && <div className="flex gap-2"><button className="btn-ghost !py-1.5 text-sm" onClick={readAll}>{t('markAllRead')}</button><button className="btn-ghost !py-1.5 text-sm text-red-600" onClick={clear}>{t('clearAll')}</button></div>}</div>
    {error && <p role="alert" className="mb-2 text-sm text-red-600">{error}</p>}
    {!list.length ? <div className="card p-8 text-center text-slate-500">{t('noneYet')}</div> : <div className="space-y-2">{list.map((n) => (
      <button key={n.id} onClick={() => open(n)} className={`card flex w-full items-center gap-3 p-3 text-left ${n.is_read ? '' : 'border-brand-500 bg-brand-50 dark:bg-slate-800'}`}>
        <Avatar name={n.actor?.full_name ?? '?'} url={n.actor?.avatar_url} />
        <div className="min-w-0 flex-1"><p className="text-sm"><b>{n.actor?.full_name}</b> {t(('n' + n.type) as Key)}</p><p className="text-xs text-slate-500">{timeAgo(n.created_at, lang, t('justNow'))}</p></div>
        {!n.is_read && <span className="h-2.5 w-2.5 rounded-full bg-brand-500" />}</button>))}</div>}
  </div>);
}
