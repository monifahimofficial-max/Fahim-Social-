'use client';
import { useEffect, useState } from 'react';
import { createClient } from '@/lib/supabase/client';
export function useCounts(userId: string) {
  const [c, setC] = useState({ notifications: 0, messenger: 0 });
  useEffect(() => {
    const sb = createClient();
    const refresh = async () => {
      const [n, u] = await Promise.all([
        sb.from('notifications').select('id', { count: 'exact', head: true }).eq('user_id', userId).eq('is_read', false), sb.rpc('unread_counts')]);
      setC({ notifications: n.count ?? 0, messenger: ((u.data as any[]) ?? []).reduce((a, x) => a + Number(x.n), 0) });
    };
    refresh();
    const ch = sb.channel('counts')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'notifications', filter: `user_id=eq.${userId}` }, refresh)
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'messages' }, async (p) => {
        const m: any = p.new;
        if (m.sender_id !== userId) await sb.from('messages').update({ delivered_at: new Date().toISOString() }).eq('id', m.id).is('delivered_at', null);
        refresh();
      })
      .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'conversation_members', filter: `user_id=eq.${userId}` }, refresh)
      .subscribe();
    window.addEventListener('counts:refresh', refresh);
    return () => { sb.removeChannel(ch); window.removeEventListener('counts:refresh', refresh); };
  }, [userId]);
  return c;
}
