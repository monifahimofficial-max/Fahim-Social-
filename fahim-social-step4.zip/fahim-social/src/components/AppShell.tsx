'use client';
import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import { Search, Home, Users, PlayCircle, UsersRound, Bell, MessageCircle, User, Settings, LogOut } from 'lucide-react';
import { useApp } from './Providers';
import { useCounts } from './Counts';
import { createClient } from '@/lib/supabase/client';
import { Key } from '@/lib/i18n';
const NAV: { href: string; key: Key; Icon: typeof Home }[] = [
  { href: '/', key: 'home', Icon: Home }, { href: '/friends', key: 'friends', Icon: Users }, { href: '/search', key: 'search', Icon: Search },
  { href: '/watch', key: 'watch', Icon: PlayCircle }, { href: '/groups', key: 'groups', Icon: UsersRound },
  { href: '/notifications', key: 'notifications', Icon: Bell }, { href: '/messenger', key: 'messenger', Icon: MessageCircle },
  { href: '/profile', key: 'profile', Icon: User }, { href: '/settings', key: 'settings', Icon: Settings },
];
const BOTTOM = ['/', '/friends', '/watch', '/groups', '/notifications'];
const Badge = ({ n }: { n?: number }) => (n ? <span className="ml-auto min-w-[20px] rounded-full bg-red-500 px-1.5 text-center text-xs text-white">{n > 99 ? '99+' : n}</span> : null);
export default function AppShell({ profile, userId, children }: { profile: { full_name: string; is_suspended: boolean } | null; userId: string; children: React.ReactNode }) {
  const { t } = useApp(); const counts = useCounts(userId); const path = usePathname(); const router = useRouter();
  const active = (h: string) => (h === '/' ? path === '/' : path.startsWith(h));
  async function logout() { await createClient().auth.signOut(); router.push('/login'); router.refresh(); }
  if (profile?.is_suspended)
    return (<main className="grid min-h-screen place-items-center p-6 text-center">
      <div className="card max-w-sm p-6"><p className="mb-4">{t('suspended')}</p><button className="btn-primary" onClick={logout}>{t('logout')}</button></div></main>);
  return (
    <div className="min-h-screen">
      <aside className="fixed inset-y-0 left-0 z-20 hidden w-64 flex-col border-r border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-slate-900 md:flex">
        <div className="mb-6 flex items-center gap-3 px-2">
          <div className="grid h-10 w-10 place-items-center rounded-xl bg-brand-500 font-bold text-white">F</div>
          <span className="text-lg font-bold">{t('appName')}</span>
        </div>
        <nav className="flex-1 space-y-1">
          {NAV.map(({ href, key, Icon }) => (
            <Link key={href} href={href} className={`flex items-center gap-3 rounded-xl px-3 py-2.5 font-medium transition ${active(href) ? 'bg-brand-50 text-brand-600 dark:bg-slate-800 dark:text-brand-100' : 'hover:bg-slate-100 dark:hover:bg-slate-800'}`}>
              <Icon size={20} />{t(key)}<Badge n={(counts as any)[key]} />
            </Link>))}
        </nav>
        <button onClick={logout} className="flex items-center gap-3 rounded-xl px-3 py-2.5 text-red-600 hover:bg-red-50 dark:hover:bg-slate-800"><LogOut size={20} />{t('logout')}</button>
      </aside>
      <header className="sticky top-0 z-20 flex items-center justify-between border-b border-slate-200 bg-white/90 px-4 py-3 backdrop-blur dark:border-slate-800 dark:bg-slate-900/90 md:hidden">
        <span className="text-lg font-bold text-brand-600">{t('appName')}</span>
        <div className="flex gap-1">
          {[{ h: '/search', I: Search }, { h: '/messenger', I: MessageCircle }, { h: '/profile', I: User }, { h: '/settings', I: Settings }].map(({ h, I }) => (
            <Link key={h} href={h} className="rounded-full p-2 hover:bg-slate-100 dark:hover:bg-slate-800"><I size={22} /></Link>))}
        </div>
      </header>
      <main className="mx-auto max-w-2xl animate-fadeUp p-4 pb-24 md:ml-64 md:max-w-3xl md:pb-8">{children}</main>
      <nav className="fixed inset-x-0 bottom-0 z-20 flex border-t border-slate-200 bg-white pb-[env(safe-area-inset-bottom)] dark:border-slate-800 dark:bg-slate-900 md:hidden">
        {NAV.filter((n) => BOTTOM.includes(n.href)).map(({ href, key, Icon }) => (
          <Link key={href} href={href} className={`flex flex-1 flex-col items-center gap-0.5 py-2 text-xs ${active(href) ? 'text-brand-600' : 'text-slate-500'}`}>
            <Icon size={22} />{t(key)}<Badge n={(counts as any)[key]} /></Link>))}
      </nav>
    </div>
  );
}
