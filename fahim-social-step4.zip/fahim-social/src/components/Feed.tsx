'use client';
import { useCallback, useEffect, useRef, useState } from 'react';
import { createClient } from '@/lib/supabase/client';
import { useApp } from './Providers';
import Composer from './Composer';
import PostCard from './PostCard';
import { Extra, Me, Post, RType } from '@/lib/types';
const PAGE = 10;
const SELECT = '*, author:profiles!author_id(id,full_name,username,avatar_url), media:post_media(url,media_type,position), shared:posts!shared_post_id(id,content,author:profiles!author_id(full_name,username))';
export default function Feed({ me }: { me: Me }) {
  const { t } = useApp(); const sb = createClient();
  const [posts, setPosts] = useState<Post[]>([]); const [extras, setExtras] = useState<Record<string, Extra>>({});
  const [loading, setLoading] = useState(true); const [more, setMore] = useState(false); const [error, setError] = useState(false);
  const busy = useRef(false); const sentinel = useRef<HTMLDivElement>(null);
  const load = useCallback(async (reset: boolean, cursor?: string) => {
    if (busy.current) return; busy.current = true; setLoading(true); setError(false);
    let q = sb.from('posts').select(SELECT).is('group_id', null).order('created_at', { ascending: false }).limit(PAGE);
    if (cursor) q = q.lt('created_at', cursor);
    const { data, error } = await q;
    if (error) { setError(true); setLoading(false); busy.current = false; return; }
    const rows = (data as unknown as Post[]) ?? []; const ids = rows.map((p) => p.id); const ex: Record<string, Extra> = {};
    rows.forEach((p) => (ex[p.id] = { counts: {}, mine: null, comments: 0 }));
    if (ids.length) {
      const [r, c] = await Promise.all([
        sb.from('reactions').select('post_id,type,user_id').in('post_id', ids), sb.from('comments').select('post_id').in('post_id', ids)]);
      r.data?.forEach((x) => { const e = ex[x.post_id]; e.counts[x.type as RType] = (e.counts[x.type as RType] ?? 0) + 1; if (x.user_id === me.id) e.mine = x.type as RType; });
      c.data?.forEach((x) => { ex[x.post_id].comments++; });
    }
    setPosts((p) => (reset ? rows : [...p, ...rows])); setExtras((e) => (reset ? ex : { ...e, ...ex }));
    setMore(rows.length === PAGE); setLoading(false); busy.current = false;
  }, [me.id]); // eslint-disable-line
  useEffect(() => { load(true); }, [load]);
  useEffect(() => {
    const el = sentinel.current; if (!el || !more) return;
    const io = new IntersectionObserver(([e]) => { if (e.isIntersecting && posts.length) load(false, posts[posts.length - 1].created_at); }, { rootMargin: '300px' });
    io.observe(el); return () => io.disconnect();
  }, [more, posts, load]);
  return (
    <div>
      <Composer me={me} onPosted={() => load(true)} />
      {posts.map((p) => <PostCard key={p.id} post={p} extra={extras[p.id]} me={me} onDeleted={(id) => setPosts((x) => x.filter((y) => y.id !== id))} onShared={() => load(true)} />)}
      {loading && <div className="space-y-3">{[0, 1].map((i) => <div key={i} className="card h-32 animate-pulse" />)}</div>}
      {error && <div className="card p-6 text-center"><p className="mb-3 text-red-600">{t('loadError')}</p><button className="btn-primary" onClick={() => load(posts.length === 0, posts.at(-1)?.created_at)}>{t('retry')}</button></div>}
      {!loading && !error && posts.length === 0 && <div className="card p-8 text-center text-slate-500">{t('noPosts')}</div>}
      {more && !loading && <div ref={sentinel} className="py-4 text-center"><button className="btn-ghost" onClick={() => load(false, posts.at(-1)?.created_at)}>{t('loadMore')}</button></div>}
    </div>);
}
