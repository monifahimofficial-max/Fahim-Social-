'use client';
import { useCallback, useEffect, useRef, useState } from 'react';
import { useRouter } from 'next/navigation';
import { ArrowLeft, Paperclip, Plus, Search, Send, Trash2 } from 'lucide-react';
import { createClient } from '@/lib/supabase/client';
import { useApp } from './Providers';
import { useOnline } from './Presence';
import Avatar from './Avatar';
import { refreshCounts } from '@/lib/notify';
import { timeAgo } from '@/lib/time';
import { Author, Me } from '@/lib/types';
type Msg = { id: string; conversation_id: string; sender_id: string; content: string | null; media_url: string | null; media_type: 'image' | 'video' | 'file' | null; delivered_at: string | null; deleted_at: string | null; created_at: string };
type Member = { conversation_id: string; user_id: string; last_read_at: string; profile: Author };
type Conv = { id: string; is_group: boolean; name: string | null; updated_at: string; members: Member[]; last: Msg | null; unread: number };
function Attachment({ path, type }: { path: string; type: string | null }) {
  const [url, setUrl] = useState('');
  useEffect(() => { createClient().storage.from('chat-files').createSignedUrl(path, 3600).then(({ data }) => setUrl(data?.signedUrl ?? '')); }, [path]);
  if (!url) return <div className="h-24 w-40 animate-pulse rounded-lg bg-slate-200 dark:bg-slate-700" />;
  if (type === 'image') return <a href={url} target="_blank" rel="noopener noreferrer"><img src={url} alt="" className="max-h-60 rounded-lg" /></a>;
  if (type === 'video') return <video src={url} controls className="max-h-60 rounded-lg" />;
  return <a href={url} target="_blank" rel="noopener noreferrer" className="underline">📎 {path.split('/').pop()}</a>;
}
export default function Messenger({ me, initial }: { me: Me; initial?: string }) {
  const { t, lang } = useApp(); const sb = createClient(); const router = useRouter(); const online = useOnline();
  const [convs, setConvs] = useState<Conv[] | null>(null); const [active, setActive] = useState<string | null>(initial ?? null);
  const [msgs, setMsgs] = useState<Msg[]>([]); const [draft, setDraft] = useState(''); const [q, setQ] = useState(''); const [tq, setTq] = useState<string | null>(null);
  const [typing, setTyping] = useState(false); const [error, setError] = useState(''); const [sending, setSending] = useState(false); const [modal, setModal] = useState(false);
  const activeRef = useRef(active); activeRef.current = active;
  const bottom = useRef<HTMLDivElement>(null); const fileRef = useRef<HTMLInputElement>(null);
  const typingCh = useRef<any>(null); const lastTyping = useRef(0); const typingTimer = useRef<any>(null);
  const conv = convs?.find((c) => c.id === active) ?? null;
  const nameOf = (c: Conv) => (c.is_group ? c.name ?? '' : c.members.find((m) => m.user_id !== me.id)?.profile.full_name ?? '');
  const avatarOf = (c: Conv) => (c.is_group ? null : c.members.find((m) => m.user_id !== me.id)?.profile.avatar_url);
  const dmOnline = (c: Conv) => !c.is_group && c.members.some((m) => m.user_id !== me.id && online.has(m.user_id));
  const loadConvs = useCallback(async () => {
    const { data: mine, error } = await sb.from('conversation_members').select('conversation:conversations(id,is_group,name,updated_at)').eq('user_id', me.id);
    if (error) { setError(t('loadError')); setConvs([]); return; }
    const list: any[] = (mine ?? []).map((x: any) => x.conversation).filter(Boolean); const ids = list.map((c) => c.id);
    if (!ids.length) return setConvs([]);
    const [mem, un, lasts] = await Promise.all([
      sb.from('conversation_members').select('conversation_id,user_id,last_read_at,profile:profiles(id,full_name,username,avatar_url)').in('conversation_id', ids), sb.rpc('unread_counts'),
      Promise.all(ids.map((id) => sb.from('messages').select('*').eq('conversation_id', id).order('created_at', { ascending: false }).limit(1)))]);
    const unread: Record<string, number> = {}; ((un.data as any[]) ?? []).forEach((x) => (unread[x.conversation_id] = Number(x.n)));
    setConvs(list.map((c, i) => ({ ...c, members: ((mem.data as any[]) ?? []).filter((m) => m.conversation_id === c.id), last: (lasts[i].data as any)?.[0] ?? null, unread: unread[c.id] ?? 0 }))
      .sort((a, b) => +new Date(b.updated_at) - +new Date(a.updated_at)));
  }, [me.id]); // eslint-disable-line
  const markRead = useCallback(async (id: string) => {
    await sb.from('conversation_members').update({ last_read_at: new Date().toISOString() }).eq('conversation_id', id).eq('user_id', me.id);
    await sb.from('messages').update({ delivered_at: new Date().toISOString() }).eq('conversation_id', id).neq('sender_id', me.id).is('delivered_at', null);
    refreshCounts();
  }, [me.id]); // eslint-disable-line
  useEffect(() => { loadConvs(); }, [loadConvs]);
  useEffect(() => {
    const ch = sb.channel('messenger')
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'messages' }, (p) => {
        const m = p.new as Msg;
        if (m.conversation_id === activeRef.current) { setMsgs((x) => (x.some((y) => y.id === m.id) ? x : [...x, m])); if (m.sender_id !== me.id) markRead(m.conversation_id); }
        loadConvs();
      })
      .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'messages' }, (p) => { const m = p.new as Msg; setMsgs((x) => x.map((y) => (y.id === m.id ? { ...y, ...m } : y))); })
      .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'conversation_members' }, () => loadConvs())
      .subscribe();
    return () => { sb.removeChannel(ch); };
  }, [me.id]); // eslint-disable-line
  useEffect(() => {
    setMsgs([]); setTq(null); setTyping(false); if (!active) return;
    let alive = true;
    (async () => {
      const { data, error } = await sb.from('messages').select('*').eq('conversation_id', active).order('created_at', { ascending: false }).limit(60);
      if (!alive) return; if (error) return setError(t('loadError'));
      setMsgs(((data as Msg[]) ?? []).reverse()); await markRead(active); loadConvs();
    })();
    const ch = sb.channel('typing:' + active).on('broadcast', { event: 'typing' }, ({ payload }) => {
      if (payload.uid === me.id) return; setTyping(true); clearTimeout(typingTimer.current); typingTimer.current = setTimeout(() => setTyping(false), 3000);
    }).subscribe();
    typingCh.current = ch;
    return () => { alive = false; clearTimeout(typingTimer.current); sb.removeChannel(ch); typingCh.current = null; };
  }, [active]); // eslint-disable-line
  useEffect(() => { bottom.current?.scrollIntoView({ block: 'end' }); }, [msgs.length, typing, active]);
  function onType(v: string) {
    setDraft(v); const now = Date.now();
    if (typingCh.current && now - lastTyping.current > 2000) { lastTyping.current = now; typingCh.current.send({ type: 'broadcast', event: 'typing', payload: { uid: me.id } }); }
  }
  async function send(file?: File) {
    const text = draft.trim(); if (!active || (!text && !file) || sending) return; setSending(true); setError('');
    try {
      let path: string | null = null; let type: string | null = null;
      if (file) {
        if (file.size > 25 * 1048576) throw new Error(t('fileTooBig'));
        path = `${me.id}/${active}/${crypto.randomUUID()}.${(file.name.split('.').pop() || 'bin').toLowerCase().replace(/[^a-z0-9]/g, '')}`;
        const { error } = await sb.storage.from('chat-files').upload(path, file, { contentType: file.type || 'application/octet-stream' }); if (error) throw error;
        type = file.type.startsWith('image/') ? 'image' : file.type.startsWith('video/') ? 'video' : 'file';
      }
      const { data, error } = await sb.from('messages').insert({ conversation_id: active, sender_id: me.id, content: text || null, media_url: path, media_type: type }).select().single();
      if (error) { if (path) await sb.storage.from('chat-files').remove([path]); throw error; }
      setMsgs((x) => (x.some((y) => y.id === (data as Msg).id) ? x : [...x, data as Msg])); setDraft(''); loadConvs();
    } catch (e: any) { setError(String(e?.message).includes('Rate limit') ? t('tooMany') : e?.message || t('loadError')); } finally { setSending(false); }
  }
  async function del(m: Msg) {
    const now = new Date().toISOString(); const { error } = await sb.from('messages').update({ deleted_at: now }).eq('id', m.id);
    if (error) return setError(t('loadError')); setMsgs((x) => x.map((y) => (y.id === m.id ? { ...y, deleted_at: now } : y))); loadConvs();
  }
  const lastMine = [...msgs].reverse().find((m) => m.sender_id === me.id && !m.deleted_at);
  function status(m: Msg) {
    const others = conv?.members.filter((x) => x.user_id !== me.id) ?? [];
    const read = (x: Member) => x.last_read_at >= m.created_at;
    const seen = others.length > 0 && (conv?.is_group ? others.every(read) : others.some(read));
    return seen ? t('seen') : m.delivered_at ? t('delivered') : t('sent');
  }
  const shown = tq ? msgs.filter((m) => !m.deleted_at && m.content?.toLowerCase().includes(tq.toLowerCase())) : msgs;
  const list = (convs ?? []).filter((c) => !q || nameOf(c).toLowerCase().includes(q.toLowerCase()) || (c.last?.content ?? '').toLowerCase().includes(q.toLowerCase()));
  return (
    <div className="card flex h-[calc(100dvh-10rem)] overflow-hidden md:h-[calc(100dvh-3rem)]">
      <div className={`${active ? 'hidden md:flex' : 'flex'} w-full flex-col border-r border-slate-200 dark:border-slate-800 md:w-80`}>
        <div className="flex items-center gap-2 p-3"><h1 className="flex-1 text-lg font-bold">{t('messenger')}</h1>
          <button aria-label={t('newChat')} onClick={() => setModal(true)} className="rounded-full bg-brand-500 p-2 text-white"><Plus size={18} /></button></div>
        <div className="px-3 pb-2"><input className="input !py-2" placeholder={t('searchChats')} value={q} onChange={(e) => setQ(e.target.value)} /></div>
        <div className="flex-1 overflow-y-auto">
          {convs === null && <div className="m-3 h-14 animate-pulse rounded-xl bg-slate-100 dark:bg-slate-800" />}
          {convs && !list.length && <p className="p-4 text-center text-sm text-slate-500">{t('noChats')}</p>}
          {list.map((c) => (
            <button key={c.id} onClick={() => setActive(c.id)} className={`flex w-full items-center gap-3 px-3 py-2.5 text-left hover:bg-slate-50 dark:hover:bg-slate-800 ${c.id === active ? 'bg-brand-50 dark:bg-slate-800' : ''}`}>
              <div className="relative"><Avatar name={nameOf(c) || '?'} url={avatarOf(c)} size={44} />{dmOnline(c) && <span className="absolute bottom-0 right-0 h-3 w-3 rounded-full border-2 border-white bg-green-500 dark:border-slate-900" />}</div>
              <div className="min-w-0 flex-1"><p className="truncate font-semibold">{nameOf(c)}</p>
                <p className={`truncate text-sm ${c.unread ? 'font-semibold' : 'text-slate-500'}`}>{c.last ? (c.last.deleted_at ? t('msgDeleted') : c.last.content ?? '📎') : ''}</p></div>
              {c.unread > 0 && <span className="rounded-full bg-red-500 px-1.5 text-xs text-white">{c.unread}</span>}</button>))}
        </div>
      </div>
      <div className={`${active ? 'flex' : 'hidden md:flex'} min-w-0 flex-1 flex-col`}>
        {!conv ? <div className="m-auto text-slate-500">{t('selectChat')}</div> : (<>
          <div className="flex items-center gap-2 border-b border-slate-200 p-3 dark:border-slate-800">
            <button className="md:hidden" aria-label="back" onClick={() => setActive(null)}><ArrowLeft size={20} /></button>
            <Avatar name={nameOf(conv) || '?'} url={avatarOf(conv)} size={36} />
            <div className="min-w-0 flex-1"><p className="truncate font-semibold">{nameOf(conv)}</p>
              <p className="text-xs text-slate-500">{typing ? t('typing') : conv.is_group ? `${conv.members.length} ${t('members')}` : dmOnline(conv) ? t('online') : t('offline')}</p></div>
            <button aria-label={t('searchInChat')} onClick={() => setTq(tq === null ? '' : null)} className="rounded-full p-2 hover:bg-slate-100 dark:hover:bg-slate-800"><Search size={18} /></button>
          </div>
          {tq !== null && <div className="p-2"><input autoFocus className="input !py-2" placeholder={t('searchInChat')} value={tq} onChange={(e) => setTq(e.target.value)} /></div>}
          <div className="flex-1 space-y-1.5 overflow-y-auto p-3">
            {shown.map((m) => { const mine = m.sender_id === me.id; const sender = conv.members.find((x) => x.user_id === m.sender_id)?.profile;
              return (<div key={m.id} className={`group flex ${mine ? 'justify-end' : 'justify-start'}`}>
                <div className="max-w-[80%]">
                  {conv.is_group && !mine && <p className="px-2 text-xs text-slate-500">{sender?.full_name}</p>}
                  <div className={`flex items-center gap-1 ${mine ? 'flex-row-reverse' : ''}`}>
                    <div className={`rounded-2xl px-3 py-2 ${m.deleted_at ? 'italic text-slate-500 border border-slate-300 dark:border-slate-700' : mine ? 'bg-brand-500 text-white' : 'bg-slate-100 dark:bg-slate-800'}`}>
                      {m.deleted_at ? t('msgDeleted') : (<>{m.media_url && <Attachment path={m.media_url} type={m.media_type} />}{m.content && <p className="whitespace-pre-wrap break-words">{m.content}</p>}</>)}</div>
                    {mine && !m.deleted_at && <button aria-label={t('delete')} onClick={() => confirm(t('delete') + '?') && del(m)} className="p-1 text-slate-400 opacity-0 hover:text-red-600 group-hover:opacity-100 max-md:opacity-100"><Trash2 size={14} /></button>}</div>
                  <p className={`px-2 text-[11px] text-slate-500 ${mine ? 'text-right' : ''}`}>{timeAgo(m.created_at, lang, t('justNow'))}{mine && m.id === lastMine?.id ? ` · ${status(m)}` : ''}</p>
                </div></div>); })}
            {typing && <p className="px-2 text-sm text-slate-500">{t('typing')}</p>}
            <div ref={bottom} />
          </div>
          {error && <p role="alert" className="px-3 text-sm text-red-600">{error}</p>}
          <div className="flex items-center gap-2 border-t border-slate-200 p-3 dark:border-slate-800">
            <input ref={fileRef} type="file" hidden onChange={(e) => { const f = e.target.files?.[0]; e.target.value = ''; if (f) send(f); }} />
            <button aria-label={t('attach')} onClick={() => fileRef.current?.click()} disabled={sending} className="rounded-full p-2 hover:bg-slate-100 dark:hover:bg-slate-800"><Paperclip size={20} /></button>
            <input className="input !rounded-full !py-2" maxLength={4000} placeholder={t('typeMessage')} value={draft} onChange={(e) => onType(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && !e.shiftKey && send()} />
            <button aria-label={t('send')} onClick={() => send()} disabled={sending || !draft.trim()} className="rounded-full bg-brand-500 p-2.5 text-white disabled:opacity-50"><Send size={18} /></button>
          </div></>)}
      </div>
      {modal && <NewChat me={me} onClose={() => setModal(false)} onOpen={async (id) => { setModal(false); await loadConvs(); setActive(id); router.replace('/messenger'); }} />}
    </div>);
}
function NewChat({ me, onClose, onOpen }: { me: Me; onClose: () => void; onOpen: (id: string) => void }) {
  const { t } = useApp(); const sb = createClient();
  const [friends, setFriends] = useState<Author[] | null>(null); const [group, setGroup] = useState(false); const [sel, setSel] = useState<string[]>([]); const [name, setName] = useState(''); const [error, setError] = useState('');
  useEffect(() => { (async () => {
    const P = 'id,full_name,username,avatar_url';
    const { data } = await sb.from('friendships').select(`requester:profiles!requester_id(${P}), addressee:profiles!addressee_id(${P})`).eq('status', 'accepted').or(`requester_id.eq.${me.id},addressee_id.eq.${me.id}`);
    setFriends((data ?? []).map((r: any) => (r.requester.id === me.id ? r.addressee : r.requester)));
  })(); }, [me.id]); // eslint-disable-line
  async function dm(id: string) { const { data, error } = await sb.rpc('get_or_create_dm', { other: id }); if (error) return setError(t('loadError')); onOpen(data as string); }
  async function mk() {
    if (!name.trim() || !sel.length) return; const { data, error } = await sb.rpc('create_group_chat', { gname: name.trim(), members: sel }); if (error) return setError(t('loadError')); onOpen(data as string);
  }
  return (
    <div className="fixed inset-0 z-40 grid place-items-center bg-black/50 p-4" onClick={onClose}>
      <div className="card max-h-[80vh] w-full max-w-sm overflow-y-auto p-4" onClick={(e) => e.stopPropagation()}>
        <div className="mb-3 flex gap-2"><button className={group ? 'btn-ghost !py-1.5' : 'btn-primary !py-1.5'} onClick={() => setGroup(false)}>{t('newChat')}</button><button className={group ? 'btn-primary !py-1.5' : 'btn-ghost !py-1.5'} onClick={() => setGroup(true)}>{t('newGroup')}</button></div>
        {group && <input className="input mb-2" placeholder={t('groupName')} maxLength={60} value={name} onChange={(e) => setName(e.target.value)} />}
        {friends === null ? <div className="h-12 animate-pulse rounded-xl bg-slate-100 dark:bg-slate-800" /> : !friends.length ? <p className="py-4 text-center text-sm text-slate-500">{t('needFriends')}</p> :
          friends.map((u) => (<button key={u.id} onClick={() => (group ? setSel(sel.includes(u.id) ? sel.filter((x) => x !== u.id) : [...sel, u.id]) : dm(u.id))} className="flex w-full items-center gap-3 rounded-xl p-2 text-left hover:bg-slate-100 dark:hover:bg-slate-800">
            <Avatar name={u.full_name} url={u.avatar_url} /><span className="flex-1 font-medium">{u.full_name}</span>{group && <input type="checkbox" readOnly checked={sel.includes(u.id)} />}</button>))}
        {error && <p role="alert" className="mt-2 text-sm text-red-600">{error}</p>}
        {group && <button className="btn-primary mt-3 w-full" onClick={mk} disabled={!name.trim() || !sel.length}>{t('create')}</button>}
      </div></div>);
}
