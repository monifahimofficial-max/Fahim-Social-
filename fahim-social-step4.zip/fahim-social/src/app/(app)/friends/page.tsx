import FriendsView from '@/components/FriendsView';
import { getMe } from '@/lib/me';
export const dynamic = 'force-dynamic';
export default async function Page() { return <FriendsView me={await getMe()} />; }
