import AppShell from '@/components/AppShell';
import Presence from '@/components/Presence';
import { createClient } from '@/lib/supabase/server';
export const dynamic = 'force-dynamic';
export default async function AppLayout({ children }: { children: React.ReactNode }) {
  const sb = createClient();
  const { data: { user } } = await sb.auth.getUser();
  const { data: profile } = user ? await sb.from('profiles').select('full_name,is_suspended').eq('id', user.id).maybeSingle() : { data: null };
  return <Presence userId={user!.id}><AppShell profile={profile} userId={user!.id}>{children}</AppShell></Presence>;
}
