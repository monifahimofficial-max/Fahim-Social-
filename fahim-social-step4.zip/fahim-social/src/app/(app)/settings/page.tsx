'use client';
import { useRouter } from 'next/navigation';
import { useApp } from '@/components/Providers';
import { createClient } from '@/lib/supabase/client';
export default function Settings() {
  const { t, lang, setLang, theme, setTheme } = useApp(); const router = useRouter();
  const seg = (on: boolean) => (on ? 'btn-primary' : 'btn-ghost');
  async function logout() { await createClient().auth.signOut(); router.push('/login'); router.refresh(); }
  return (
    <div className="card space-y-5 p-5">
      <h1 className="text-xl font-bold">{t('settings')}</h1>
      <div><p className="mb-2 font-medium">{t('language')}</p><div className="flex gap-2">
        <button className={seg(lang === 'bn')} onClick={() => setLang('bn')}>বাংলা</button>
        <button className={seg(lang === 'en')} onClick={() => setLang('en')}>English</button></div></div>
      <div><p className="mb-2 font-medium">{t('theme')}</p><div className="flex gap-2">
        <button className={seg(theme === 'light')} onClick={() => setTheme('light')}>{t('light')}</button>
        <button className={seg(theme === 'dark')} onClick={() => setTheme('dark')}>{t('dark')}</button></div></div>
      <button className="btn-ghost text-red-600" onClick={logout}>{t('logout')}</button>
    </div>
  );
}
