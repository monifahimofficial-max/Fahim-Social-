import NotificationsView from '@/components/NotificationsView';
import { getMe } from '@/lib/me';
export const dynamic = 'force-dynamic';
export default async function Page() { return <NotificationsView me={await getMe()} />; }
