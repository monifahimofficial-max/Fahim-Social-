import ProfileView from '@/components/ProfileView';
import { getMe } from '@/lib/me';
export const dynamic = 'force-dynamic';
export default async function UserPage({ params }: { params: { username: string } }) {
  const me = await getMe();
  return <ProfileView username={decodeURIComponent(params.username).toLowerCase()} me={me} />;
}
