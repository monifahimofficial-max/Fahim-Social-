import SearchView from '@/components/SearchView';
import { getMe } from '@/lib/me';
export const dynamic = 'force-dynamic';
export default async function Page() { return <SearchView me={await getMe()} />; }
