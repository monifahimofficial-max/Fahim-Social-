import { redirect } from 'next/navigation';
import { getMe } from '@/lib/me';
export const dynamic = 'force-dynamic';
export default async function Profile() { const me = await getMe(); redirect(`/u/${me.username}`); }
