import Feed from '@/components/Feed';
import { createClient } from '@/lib/supabase/server';
export const dynamic = 'force-dynamic';
export default async function Home() {
  const sb = createClient();
  const { data: { user } } = await sb.auth.getUser();
  const { data: me } = await sb.from('profiles').select('id,full_name,username,avatar_url').eq('id', user!.id).single();
  return me ? <Feed me={me} /> : null;
}
