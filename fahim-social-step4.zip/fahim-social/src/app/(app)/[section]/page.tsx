import { notFound } from 'next/navigation';
import ComingSoon from '@/components/ComingSoon';
import { Key } from '@/lib/i18n';
const OK = ['watch', 'groups'];
export default function Section({ params }: { params: { section: string } }) {
  if (!OK.includes(params.section)) notFound();
  return <ComingSoon k={params.section as Key} />;
}
