import Messenger from '@/components/Messenger';
import { getMe } from '@/lib/me';
export const dynamic = 'force-dynamic';
export default async function Page({ searchParams }: { searchParams: { c?: string } }) {
  const c = searchParams.c && /^[0-9a-f-]{36}$/.test(searchParams.c) ? searchParams.c : undefined;
  return <Messenger me={await getMe()} initial={c} />;
}
