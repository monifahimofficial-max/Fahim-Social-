'use client';
import { useState, FormEvent } from 'react';
import Link from 'next/link';
import { createClient } from '@/lib/supabase/client';
import { useApp } from '@/components/Providers';
import AuthCard, { Msg } from '@/components/AuthCard';
export default function Forgot() {
  const { t } = useApp(); const sb = createClient();
  const [email, setEmail] = useState(''); const [error, setError] = useState(''); const [ok, setOk] = useState(''); const [busy, setBusy] = useState(false);
  async function submit(e: FormEvent) {
    e.preventDefault(); setError(''); setOk(''); setBusy(true);
    const { error } = await sb.auth.resetPasswordForEmail(email.trim(), { redirectTo: `${location.origin}/auth/callback?next=/reset` });
    setBusy(false);
    if (error) setError(error.message); else setOk(t('resetSent'));
  }
  return (
    <AuthCard title={t('forgot')}>
      <form onSubmit={submit} className="space-y-3">
        <input className="input" type="email" required placeholder={t('email')} value={email} onChange={(e) => setEmail(e.target.value)} />
        <Msg error={error} ok={ok} />
        <button className="btn-primary w-full" disabled={busy}>{busy ? t('loading') : t('sendReset')}</button>
      </form>
      <p className="mt-4 text-center text-sm"><Link className="text-brand-600 hover:underline" href="/login">{t('back')}</Link></p>
    </AuthCard>
  );
}
