'use client';
import { useState, FormEvent } from 'react';
import { useRouter } from 'next/navigation';
import { createClient } from '@/lib/supabase/client';
import { useApp } from '@/components/Providers';
import AuthCard, { Msg } from '@/components/AuthCard';
export default function Reset() {
  const { t } = useApp(); const sb = createClient(); const router = useRouter();
  const [pw, setPw] = useState(''); const [error, setError] = useState(''); const [ok, setOk] = useState(''); const [busy, setBusy] = useState(false);
  async function submit(e: FormEvent) {
    e.preventDefault(); setError('');
    if (pw.length < 8) return setError(t('errPassword'));
    setBusy(true);
    const { error } = await sb.auth.updateUser({ password: pw });
    setBusy(false);
    if (error) return setError(error.message);
    setOk(t('passwordUpdated')); setTimeout(() => { router.push('/'); router.refresh(); }, 1200);
  }
  return (
    <AuthCard title={t('newPassword')}>
      <form onSubmit={submit} className="space-y-3">
        <input className="input" type="password" required minLength={8} placeholder={t('newPassword')} value={pw} onChange={(e) => setPw(e.target.value)} autoComplete="new-password" />
        <Msg error={error} ok={ok} />
        <button className="btn-primary w-full" disabled={busy}>{busy ? t('loading') : t('savePassword')}</button>
      </form>
    </AuthCard>
  );
}
