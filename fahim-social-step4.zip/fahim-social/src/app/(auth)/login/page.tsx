'use client';
import { useState, FormEvent } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { createClient } from '@/lib/supabase/client';
import { useApp } from '@/components/Providers';
import AuthCard, { Msg } from '@/components/AuthCard';
export default function Login() {
  const { t } = useApp(); const router = useRouter(); const sb = createClient();
  const [email, setEmail] = useState(''); const [password, setPassword] = useState('');
  const [error, setError] = useState(''); const [busy, setBusy] = useState(false);
  async function submit(e: FormEvent) {
    e.preventDefault(); setError(''); setBusy(true);
    const { error } = await sb.auth.signInWithPassword({ email: email.trim(), password });
    setBusy(false);
    if (error) return setError(error.message);
    router.push('/'); router.refresh();
  }
  async function google() {
    const { error } = await sb.auth.signInWithOAuth({ provider: 'google', options: { redirectTo: `${location.origin}/auth/callback` } });
    if (error) setError(error.message);
  }
  return (
    <AuthCard title={t('login')}>
      <form onSubmit={submit} className="space-y-3">
        <input className="input" type="email" required placeholder={t('email')} value={email} onChange={(e) => setEmail(e.target.value)} autoComplete="email" />
        <input className="input" type="password" required placeholder={t('password')} value={password} onChange={(e) => setPassword(e.target.value)} autoComplete="current-password" />
        <Msg error={error} />
        <button className="btn-primary w-full" disabled={busy}>{busy ? t('loading') : t('login')}</button>
        <button type="button" className="btn-ghost w-full" onClick={google}>{t('google')}</button>
      </form>
      <div className="mt-4 space-y-1 text-center text-sm">
        <Link className="text-brand-600 hover:underline" href="/forgot">{t('forgot')}</Link>
        <p>{t('noAccount')} <Link className="font-semibold text-brand-600 hover:underline" href="/register">{t('register')}</Link></p>
      </div>
    </AuthCard>
  );
}
