'use client';
import { useState, FormEvent } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { createClient } from '@/lib/supabase/client';
import { useApp } from '@/components/Providers';
import AuthCard, { Msg } from '@/components/AuthCard';
export default function Register() {
  const { t } = useApp(); const router = useRouter(); const sb = createClient();
  const [f, setF] = useState({ fullName: '', username: '', email: '', password: '' });
  const [error, setError] = useState(''); const [ok, setOk] = useState(''); const [busy, setBusy] = useState(false);
  const set = (k: keyof typeof f) => (e: React.ChangeEvent<HTMLInputElement>) => setF({ ...f, [k]: e.target.value });
  async function submit(e: FormEvent) {
    e.preventDefault(); setError(''); setOk('');
    const username = f.username.trim().toLowerCase();
    if (!f.fullName.trim()) return setError(t('errName'));
    if (!/^[a-z0-9_]{3,30}$/.test(username)) return setError(t('errUsername'));
    if (f.password.length < 8) return setError(t('errPassword'));
    setBusy(true);
    const { data: taken } = await sb.from('profiles').select('id').eq('username', username).maybeSingle();
    if (taken) { setBusy(false); return setError(t('usernameTaken')); }
    const { data, error } = await sb.auth.signUp({
      email: f.email.trim(), password: f.password,
      options: { data: { username, full_name: f.fullName.trim() }, emailRedirectTo: `${location.origin}/auth/callback` },
    });
    setBusy(false);
    if (error) return setError(error.message);
    if (data.session) { router.push('/'); router.refresh(); } else setOk(t('checkEmail'));
  }
  return (
    <AuthCard title={t('register')}>
      <form onSubmit={submit} className="space-y-3">
        <input className="input" required placeholder={t('fullName')} value={f.fullName} onChange={set('fullName')} />
        <input className="input" required placeholder={t('username')} value={f.username} onChange={set('username')} autoCapitalize="none" />
        <input className="input" type="email" required placeholder={t('email')} value={f.email} onChange={set('email')} autoComplete="email" />
        <input className="input" type="password" required minLength={8} placeholder={t('password')} value={f.password} onChange={set('password')} autoComplete="new-password" />
        <Msg error={error} ok={ok} />
        <button className="btn-primary w-full" disabled={busy}>{busy ? t('loading') : t('register')}</button>
      </form>
      <p className="mt-4 text-center text-sm">{t('haveAccount')} <Link className="font-semibold text-brand-600 hover:underline" href="/login">{t('login')}</Link></p>
    </AuthCard>
  );
}
