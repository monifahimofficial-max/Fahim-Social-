import './globals.css';
import type { Metadata, Viewport } from 'next';
import Providers from '@/components/Providers';
export const metadata: Metadata = { title: 'Fahim Social', description: 'ফাহিম সোশ্যাল' };
export const viewport: Viewport = { width: 'device-width', initialScale: 1, themeColor: '#2f6bff' };
const themeScript = `try{var t=localStorage.getItem('theme');if(t==='dark'||(!t&&matchMedia('(prefers-color-scheme: dark)').matches))document.documentElement.classList.add('dark')}catch(e){}`;
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="bn" suppressHydrationWarning>
      <head><script dangerouslySetInnerHTML={{ __html: themeScript }} /></head>
      <body><Providers>{children}</Providers></body>
    </html>
  );
}
